package com.example.jokenpo;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    int pontosJogador = 0;
    int pontosPC = 0;

    TextView textResultado;
    TextView placarJogadorText;
    TextView placarPCText;
    ImageView imgResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        textResultado = findViewById(R.id.textResultado);
        placarJogadorText = findViewById(R.id.placarJogador);
        placarPCText = findViewById(R.id.placarPC);
        imgResultado = findViewById(R.id.imgResultado);
    }

    public void selecPedra(View view){
        opcaoSelecionada("pedra");
    }

    public void selecPapel(View view){
        opcaoSelecionada("papel");
    }

    public void selecTesoura(View view){
        opcaoSelecionada("tesoura");
    }

    public void opcaoSelecionada(String opcaoSelecionada){

        if(pontosJogador == 5 || pontosPC == 5){
            textResultado.setText("Partida finalizada! Clique em Reiniciar.");
            return;
        }

        int numero = new Random().nextInt(3);

        String[] opcoes = {"pedra", "papel", "tesoura"};
        String opcaoPC = opcoes[numero];

        switch (opcaoPC){
            case "pedra":
                imgResultado.setImageResource(R.drawable.pedra);
                break;

            case "papel":
                imgResultado.setImageResource(R.drawable.papel);
                break;

            case "tesoura":
                imgResultado.setImageResource(R.drawable.tesoura);
                break;
        }

        if(
                (opcaoPC.equals("tesoura") && opcaoSelecionada.equals("papel")) ||
                        (opcaoPC.equals("papel") && opcaoSelecionada.equals("pedra")) ||
                        (opcaoPC.equals("pedra") && opcaoSelecionada.equals("tesoura"))
        ){
            textResultado.setText("PERDEU, MANÉ!!");
            pontosPC++;

        } else if (
                (opcaoSelecionada.equals("tesoura") && opcaoPC.equals("papel")) ||
                        (opcaoSelecionada.equals("papel") && opcaoPC.equals("pedra")) ||
                        (opcaoSelecionada.equals("pedra") && opcaoPC.equals("tesoura"))
        ){
            textResultado.setText("GANHOU!!");
            pontosJogador++;

        } else {
            textResultado.setText("Empate!");
        }

        // Atualiza os placares individuais
        placarPCText.setText(String.valueOf(pontosPC));
        placarJogadorText.setText(String.valueOf(pontosJogador));

        if(pontosJogador == 5){
            textResultado.setText("FIM DE JOGO - VOCÊ GANHOU!");
        }

        if(pontosPC == 5){
            textResultado.setText("FIM DE JOGO - PC GANHOU, MANÉ!");
        }
    }

    public void reiniciarPartida(View view){
        pontosJogador = 0;
        pontosPC = 0;

        placarPCText.setText("0");
        placarJogadorText.setText("0");
        textResultado.setText("Nova partida iniciada!");

        imgResultado.setImageResource(R.drawable.padrao);
    }
}